public class Main {
  public static void main(String[] args) {
    int x = 18;
    int y = 18;
    if (x == y) {
        //if(x=y) -equivalent mutant
      System.out.println("x is equal to y");
    }  
  }
}
