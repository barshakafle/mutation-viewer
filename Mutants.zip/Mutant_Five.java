public class Main {
  public static void main(String[] args) {
    int time = 20;
    if (time > 18) {
        //if (time >= 18){-equivalent mutant
      System.out.println("Good evening.");

    } else {
      System.out.println("Good day.");
    }  
  }
}