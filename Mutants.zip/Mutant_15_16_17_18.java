lass Main {
  public static void main(String[] args) {

    String[] words = { "Ruby", "C", "Python", "Java" };

    for(int i = 0; i < 3; ++i) {
        //for(int i = 0; i <= 3; ++i) { -equivalent mutant
      for (int j = i + 1; j < 4; ++j) {
          //for (int j = i + 1; j <= 4; ++j) { -equivalent mutant
          
        if (words[i].compareTo(words[j]) > 0) {
        //if (words[i].compareTo(words[j]) >= 0) { -equivalent mutant
          // swap words[i] with words[j[
          String temp = words[i];
          words[i] = words[j];
          words[j] = temp;
        }
      }
    }

    System.out.println("In lexicographical order:");
    
    for(int i = 0; i < 4; i++) {
        //for(int i = 0; i <= 4; i++) { -equivalent mutant
      System.out.println(words[i]);
    }
  }
}